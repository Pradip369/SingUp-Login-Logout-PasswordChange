from django.contrib import admin
# from roll.models import Student

# # Register your models here.
# class StudentAdmin(admin.ModelAdmin):
#     list_display = ["name","surname"]
# admin.site.register(Student,StudentAdmin)