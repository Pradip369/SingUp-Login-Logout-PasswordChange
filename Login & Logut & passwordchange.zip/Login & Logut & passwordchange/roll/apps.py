from django.apps import AppConfig


class RollConfig(AppConfig):
    name = 'roll'
