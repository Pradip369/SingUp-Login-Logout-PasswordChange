from django.shortcuts import render
from .forms import SignUpForm,UserProfileForm,AdminProfileForm
from django.contrib.auth.forms import AuthenticationForm, PasswordChangeForm
from django.contrib.auth import authenticate, login,logout,\
    update_session_auth_hash
from django.http.response import HttpResponseRedirect
from django.contrib import messages
from django.contrib.auth.models import Group,User


def sign_up(request):
    if request.method=="POST":
        fm = SignUpForm(request.POST)
        if fm.is_valid():
            fm.save()
            # group = Group.objects.get(name='manager')
            # user.groups.add(group)
            return HttpResponseRedirect("/roll/login_user/")
    else:
        fm = SignUpForm()
    return render(request,'signup.html',{"fm":fm})

def login_user(request):
    if not request.user.is_authenticated:
        if request.method == "POST":
            fm = AuthenticationForm(request=request,data=request.POST)
            if fm.is_valid():
                uname = fm.cleaned_data['username']
                upw = fm.cleaned_data['password']
                user = authenticate(request=request,username=uname,password=upw)
                if user is not None:
                    login(request,user)
                    return HttpResponseRedirect("/roll/profile/")
                else:
                    print("Locha")
        else:
            fm = AuthenticationForm()
        return render(request, "login.html",{"fm":fm})
    else:
        return HttpResponseRedirect("/roll/profile/")

def logout_user(request):
    logout(request)
    return HttpResponseRedirect("/roll/login_user/")

def changepassword(request):
    if request.user.is_authenticated:
        if request.method == "POST":
            fm = PasswordChangeForm(user=request.user,data=request.POST)
            if fm.is_valid():
                fm.save()
                update_session_auth_hash(request,fm.user)
                messages.success(request,"You changed password Successfully ")
                return HttpResponseRedirect("/roll/profile/")
        else:
            fm = PasswordChangeForm(user=request.user)
    else:
        return HttpResponseRedirect("/roll/login_user/")
    return render(request,"changepass.html",{"fm":fm})

def profile(request):
    if request.user.is_authenticated:
        if request.method=="POST":
            if request.user.is_superuser:
                fm = AdminProfileForm(request.POST,instance=request.user)
            else:
                fm = UserProfileForm(request.POST,instance=request.user)
            if fm.is_valid():
                fm.save()
                messages.success(request,"Profile Updated!!!")
                return HttpResponseRedirect("/roll/profile/")
        else:
            if request.user.is_superuser==True:
                fm = AdminProfileForm(instance=request.user)
            else:
                fm = UserProfileForm(instance=request.user)
                # return HttpResponseRedirect("/roll/login_user/")

        return render(request,"profile.html",{"us":request.user,"fm":fm})
    else:
        return HttpResponseRedirect("/roll/login_user/")


def userdashbord(request):
    if request.user.is_authenticated:
        return render(request,"dash.html",{"nm":request.user.username})
    else:
        return HttpResponseRedirect("/roll/login_user")








