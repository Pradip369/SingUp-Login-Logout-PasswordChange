from django.contrib import admin
from .models import Modal

# Register your models here.
class ModalAdmin(admin.ModelAdmin):
    list_display = ["name","surname"]
admin.site.register(Modal,ModalAdmin)